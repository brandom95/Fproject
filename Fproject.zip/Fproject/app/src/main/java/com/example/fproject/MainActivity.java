package com.example.fproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements ApiTask.ApiCallback {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button apiButton = findViewById(R.id.apiButton);
        apiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Initiate the API call when the button is clicked
                new ApiTask(MainActivity.this).execute();
            }
        });
    }

    @Override
    public void onSuccess(String result) {
        // Handle successful response
        Log.d(TAG, "API Result: " + result);
    }

    @Override
    public void onError(String error) {
        // Handle error
        Log.e(TAG, "API Error: " + error);
    }
}
